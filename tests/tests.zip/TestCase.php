<?php

namespace Tests;

use Illuminate\Foundation\Testing\TestCase as CommentTestCase;

abstract class TestCase extends CommentTestCase
{
    use CreatesApplication;

    /**
     * Setup the test environment.
     *
     * @return void
     */
    public function setUp()
    {
        parent::setUp();

        $this->migrateTables();

        //$this->withFactories(__DIR__ . '/factories');
    }


    private function migrateTables()
    {
        $this->artisan('migrate', [
            '--database' => 'testing',
            '--realpath' => realpath(__DIR__ . '/migrations'),
        ]);

    }
}
