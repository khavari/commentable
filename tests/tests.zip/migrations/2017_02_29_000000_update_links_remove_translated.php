<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class UpdateLinksRemoveTranslated extends Migration
{
    public function up()
    {
        Schema::table("links", function (Blueprint $table) {
            $table->dropColumn(['title', 'url']);
            $table->string("icon")->nullable()->default(null)->change();
        });
    }

    public function down()
    {
        Schema::table("links", function (Blueprint $table) {
            $table->string("title")->default(null);
            $table->string("url")->default(null);
        });
    }
}
