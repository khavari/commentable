<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class AddHistoryToTransactions extends Migration
{
    public function up()
    {
        Schema::create("transaction_log", function (Blueprint $table) {
            $table->increments("id");
            $table->integer("transaction_id")->unsigned();
            $table->text("log");
            $table->timestamps();
        });

        Schema::table("transaction_log", function (Blueprint $table) {
            $table->foreign("transaction_id")->references("id")->on("checkouts")->onDelete("cascade");
        });
    }

    public function down()
    {
        Schema::drop("transaction_log");
    }
}