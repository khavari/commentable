<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class AddTemplatesForVocabularies extends Migration
{
    public function up()
    {
        Schema::create("templates", function (Blueprint $table) {
            $table->increments("id");
            $table->string("code")->index();
            $table->string("title");
            $table->json("data")->nullable();

            $table->integer("templatable_id");
            $table->string("templatable_type");
        });
    }

    public function down()
    {
        Schema::drop("templates");
    }
}