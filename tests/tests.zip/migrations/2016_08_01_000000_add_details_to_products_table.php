<?php

class AddDetailsToProductsTable extends \Illuminate\Database\Migrations\Migration
{
    public function up()
    {
        Schema::table("product_translations", function ($table) {
            $table->text('details')->nullable();
        });
    }

    public function down()
    {
        Schema::table("product_translations", function ($table) {
            $table->dropColumn('details');
        });
    }
}
