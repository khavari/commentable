<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class MakeJsonFieldLarger extends Migration
{
    public function up()
    {
        Schema::table('payments', function (Blueprint $table) {
            $table->longText('details')->change();
        });
    }

    public function down()
    {
        Schema::table('payments', function (Blueprint $table) {
            $table->text('details')->change();
        });
    }
}
