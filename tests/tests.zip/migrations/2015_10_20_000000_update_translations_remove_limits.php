<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class UpdateTranslationsRemoveLimits extends Migration {

    public function up()
    {
         DB::statement('ALTER TABLE product_category_translations CHANGE description description TEXT');
    }

    public function down()
    {
         DB::statement('ALTER TABLE product_category_translations CHANGE description  description VARCHAR( 255 )');
    }
}
