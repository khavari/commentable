<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateDeliveryOptionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('delivery_options', function (Blueprint $table) {
            $table->increments('id')->unsigned();
            $table->timestamps();
        });

        Schema::create('delivery_option_translations', function (Blueprint $table) {
            $table->increments('id');
            $table->string('locale');
            $table->integer('delivery_option_id')->unsigned();
            $table->string('name');
            $table->bigInteger('base_price');
            $table->boolean('enabled')->default(0);
            $table->json('conditions');
            $table->timestamps();
        });

        Schema::table("delivery_option_translations", function (Blueprint $table) {
            $table->unique(['delivery_option_id', 'locale']);
            $table->foreign('delivery_option_id')->references('id')->on('delivery_options')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('delivery_option_translations');
        Schema::dropIfExists('delivery_options');
    }
}
