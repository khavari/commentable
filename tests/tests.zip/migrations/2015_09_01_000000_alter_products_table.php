<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class AlterProductsTable
{
    public function up()
    {
        Schema::table("products", function ($table) {
            $table->integer('views')->default(0);
            $table->boolean('featured')->default(false);
        });
    }

    public function down()
    {
        Schema::table("products", function ($table) {
            $table->dropColumn(['views', 'featured']);
        });
    }
}