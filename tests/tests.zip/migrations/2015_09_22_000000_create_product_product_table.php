<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateProductProductTable extends Migration
{
    public function up()
    {
        Schema::create("product_product", function (Blueprint $table) {
            $table->increments("id");
            $table->integer("product_id")->unsigned();
            $table->integer("related_id")->unsigned();
            $table->integer("order")->unsigned();
        });

        Schema::table("product_product", function (Blueprint $table) {
            $table->unique(['product_id', 'related_id']);
            $table->foreign("product_id")->references("id")->on("products")->OnDelete("cascade");
        });

    }

    public function down()
    {
        Schema::drop("product_product");
    }
}