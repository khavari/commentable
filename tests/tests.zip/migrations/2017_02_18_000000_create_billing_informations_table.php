<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateBillingInformationsTable extends Migration
{
    public function up()
    {
        Schema::create("billing_informations", function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string("name");
            $table->text("address");
            $table->boolean('is_company')->default(true);
            $table->string('phone');
            $table->string('mobile');
            $table->string('national_code');
            $table->string('national_id');
            $table->string('economic_code');
            $table->string('register_number');
            $table->string('postal_code');
            $table->string('email');
            $table->string('website');
            $table->integer('user_id')->unsigned();
            $table->timestamps();
        });

        Schema::table('billing_informations', function (Blueprint $table) {
            $table->foreign(['user_id'])->references("id")->on("users")->onDelete("cascade");
        });
    }

    public function down()
    {
        Schema::dropIfExists('billing_informations');
    }
}
