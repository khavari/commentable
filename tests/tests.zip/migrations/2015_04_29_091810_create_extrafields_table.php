<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateExtrafieldsTable extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::create('extrafields', function (Blueprint $table) {
            $table->increments('id');
            $table->string('title');
            $table->string('css')->nullable();
            $table->enum('type', ['string', 'text']);
            $table->string('defaults')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down()
    {
        Schema::drop('extrafields');
    }
}
