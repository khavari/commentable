<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class UpdateUsersRoles extends Migration
{
    public function up()
    {
        Schema::create('role_user', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('user_id')->unsigned();
            $table->integer('role_id')->unsigned();
            $table->timestamps();
        });

        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('role_id');
        });

        Schema::table('permissions', function (Blueprint $table) {
            $table->string('uri');
            $table->string('action');
            $table->string('method');
            $table->dropColumn(['title', 'slug']);
        });
    }

    public function down()
    {
        Schema::dropIfExists('role_user');

        Schema::table('users', function (Blueprint $table) {
            $table->integer('role_id')->unsigned();
        });

        Schema::table('permissions', function (Blueprint $table) {
            $table->dropColumn(['uri', 'action', 'method']);

            $table->string('title');
            $table->string('slug');
        });
    }
}
