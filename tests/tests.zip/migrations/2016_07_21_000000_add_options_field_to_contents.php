<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class AddOptionsFieldToContents extends Migration
{
    public function up()
    {
        Schema::table('content_translations', function ($table) {
            $table->json('options');
        });

        Schema::table('contents', function ($table) {
            $table->json('options');
        });
    }

    public function down()
    {
        Schema::table('contents', function (Blueprint $table) {
            $table->dropColumn('options');
        });

        Schema::table('content_translations', function (Blueprint $table) {
            $table->dropColumn('options');
        });
    }
}
