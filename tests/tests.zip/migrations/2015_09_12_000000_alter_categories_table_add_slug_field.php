<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class AlterCategoriesTableAddSlugField
{
    /**
     *
     */
    public function up()
    {
        Schema::table("product_categories", function ($table) {
            $table->text('slug')->nullable()->default(null);
        });

    }

    public function down()
    {
        Schema::table("product_categories", function ($table) {
            $table->dropColumn('slug');
        });
    }
}

