<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class UpgradeToLaravel54 extends Migration
{
    public function up()
    {
//        Schema::table("logo-rotators", function (Blueprint $table) {
//            $table->string("alt_text")->nullable()->default(null)->change()->toSql();
//        });
    }

    public function down()
    {
    }
}
