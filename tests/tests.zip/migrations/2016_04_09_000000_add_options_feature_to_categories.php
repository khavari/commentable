<?php

use Illuminate\Database\Migrations\Migration;

class AddOptionsFeatureToCategories extends Migration
{
    public function up()
    {
        Schema::table('categories', function ($table) {
            $table->text('options');
        });

        Schema::table('category_translations', function ($table) {
            $table->text('options');
        });
    }

    public function down()
    {
        Schema::table('categories', function ($table) {
            $table->dropColumn('options');
        });

        Schema::table('category_translations', function ($table) {
            $table->dropColumn('options');
        });
    }
}
