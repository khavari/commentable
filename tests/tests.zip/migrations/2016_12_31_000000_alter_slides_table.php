<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AlterSlidesTable extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::table('slides', function (Blueprint $table) {
            $table->text('text_color')->nullable();
            $table->text('link_color')->nullable();
            $table->text('link_hover_color')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down()
    {
        Schema::table("slides", function (Blueprint $table) {
            $table->dropColumn("text_color");
            $table->dropColumn("link_color");
            $table->dropColumn("link_hover_color");
        });
    }
}
