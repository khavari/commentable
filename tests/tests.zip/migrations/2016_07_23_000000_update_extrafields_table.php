<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class UpdateExtrafieldsTable extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::table('extrafields', function (Blueprint $table) {
            $table->dropColumn('type');
        });

        Schema::table('extrafields', function (Blueprint $table) {
            $table->string('type');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down()
    {
        Schema::table('extrafields', function (Blueprint $table) {
            $table->dropColumn('type');
        });

        Schema::table('extrafields', function (Blueprint $table) {
            $table->enum('type', ['string', 'text']);
        });


    }
}
