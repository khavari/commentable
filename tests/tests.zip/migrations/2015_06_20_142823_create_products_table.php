<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProductsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('products', function (Blueprint $table) {
            $table->increments('id');
            $table->string('title')->nullable();
            $table->text('description')->nullable()->default(null);
            $table->string('slug')->nullable()->default(null)->index();
            $table->decimal('price', 12, 0)->nullable()->default(0);
            $table->integer('category_id')->unsigned();
            $table->integer('attribute_set_id')->unsigned();
            $table->unique('title');
            $table->unique('slug');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('products');
    }
}
