<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateSlidesTable extends Migration
{
    /**
     * Reverse the migrations.
     */
    public function down()
    {
        Schema::dropIfExists('slides');
    }

    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::create('slides', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name')->nullable();
            $table->string('url');
            $table->string('title')->nullable();
            $table->text('description')->nullable();
            $table->integer('order', false, true);
            $table->integer('slideshow_id')->unsigned();
            $table->timestamps();
        });
    }
}
