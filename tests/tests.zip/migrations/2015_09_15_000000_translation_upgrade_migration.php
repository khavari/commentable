<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class TranslationUpgradeMigration extends Migration
{
    public function up()
    {
        $this->upgradeAuthorsTable();
        $this->upgradeCategoriesTable();
        $this->upgradeContentsTable();
        $this->upgradeExtrafieldsTable();
        $this->upgradeVocabularyTable();
    }

    public function down()
    {
        $this->downgrade();
    }

    private function upgradeAuthorsTable()
    {
        Schema::create("author_translations", function (Blueprint $table) {
            $table->increments('id');
            $table->integer('author_id')->unsigned();
            $table->string("name")->nullable();
            $table->mediumText("description");
            $table->string('locale')->index();
        });

        Schema::table("author_translations", function (Blueprint $table) {
            $table->unique(['author_id', 'locale']);
            $table->foreign('author_id')->references('id')->on('authors')->onDelete('cascade');
        });
    }

    private function upgradeCategoriesTable()
    {
        Schema::create("category_translations", function (Blueprint $table) {
            $table->increments("id");
            $table->integer("category_id")->unsigned();
            $table->string("title");
            $table->string("description");
            $table->string('locale')->index();
        });
        Schema::table("category_translations", function (Blueprint $table) {
            $table->unique(['category_id', "locale"]);
            $table->foreign("category_id")->references('id')->on("categories")->onDelete("cascade");
        });

    }

    private function upgradeContentsTable()
    {
        Schema::create("content_translations", function (Blueprint $table) {
            $table->increments("id");
            $table->integer("content_id")->unsigned();
            $table->string("title");
            $table->text("body");
            $table->string('locale')->index();
        });

        Schema::table("content_translations", function (Blueprint $table) {
            $table->unique(['content_id', 'locale']);
            $table->foreign("content_id")->references("id")->on("contents")->onDelete("cascade");
        });
    }

    private function upgradeExtrafieldsTable()
    {
        Schema::create("extrafield_translations", function (Blueprint $table) {
            $table->increments('id');
            $table->integer("extrafield_id")->unsigned();
            $table->string("title");
            $table->string("css")->nullable();
            $table->string("value")->nullable();
            $table->string('locale')->index();
        });

        Schema::table("extrafield_translations", function (Blueprint $table) {
            $table->unique(["extrafield_id", "locale"]);
            $table->foreign("extrafield_id")->references("id")->on("extrafields")->onDelete("cascade");
        });

    }

    public function upgradeVocabularyTable()
    {
        Schema::create("vocabulary_translations", function (Blueprint $table) {
            $table->increments("id");
            $table->integer("vocabulary_id")->unsigned();
            $table->string("title");
            $table->mediumtext("description");
            $table->string('locale')->index();
        });

        Schema::table("vocabulary_translations", function (Blueprint $table) {

            $table->unique(['vocabulary_id', 'locale']);
            $table->foreign("vocabulary_id")->references("id")->on("vocabulary");
        });
    }

    public function downgrade()
    {
        Schema::drop('vocabulary_translations');
        Schema::drop('extrafield_translations');
        Schema::drop('content_translations');
        Schema::drop('author_translations');
        Schema::drop('category_translations');
    }

}