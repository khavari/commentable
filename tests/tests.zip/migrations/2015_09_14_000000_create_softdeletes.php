<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateSoftdeletes extends Migration
{
    public function up()
    {
        Schema::table('categories', function (Blueprint $table) {
            $table->softDeletes();
        });

        Schema::table('extrafields', function (Blueprint $table) {
            $table->softDeletes();
        });

        Schema::table('vocabulary', function (Blueprint $table) {
            $table->softDeletes();
        });
    }

    public function down()
    {

    }
}