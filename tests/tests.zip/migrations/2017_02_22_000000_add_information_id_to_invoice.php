<?php


use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class AddInformationIdToInvoice extends Migration
{
    public function up()
    {
        Schema::table("invoices", function (Blueprint $table) {
            $table->unsignedInteger('information_id')->nullable()->default(null);
        });
    }

    public function down()
    {
        Schema::table("invoices", function (Blueprint $table) {
            $table->dropColumn('information_id');
        });
    }
}
