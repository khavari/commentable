<?php


use Illuminate\Database\Migrations\Migration;

class AlterProductsTableAddOrderField extends Migration
{
    public function up()
    {
        Schema::table('products', function ($table) {
            $table->integer('order')->nullable();
        });
    }

    public function down()
    {
        Schema::table("products", function ($table) {
            $table->dropColumn('order');
        });
    }
}