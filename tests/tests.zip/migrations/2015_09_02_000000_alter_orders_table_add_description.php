<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class AlterOrdersTableAddDescription
{
    public function up()
    {
        Schema::table("orders", function ($table) {
            $table->string('description')->nullable();
        });
    }

    public function down()
    {
        Schema::table("orders", function ($table) {
            $table->dropColumn(['description']);
        });
    }
}