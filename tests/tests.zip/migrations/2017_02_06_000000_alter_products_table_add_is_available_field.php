<?php


use Illuminate\Database\Migrations\Migration;

/**
 * Class AlterProductsTableAddIsAvailableField
 */
class AlterProductsTableAddIsAvailableField extends Migration
{
    /**
     *
     */
    public function up()
    {
        Schema::table('products', function ($table) {
            $table->boolean('is_available')->default(true);
        });
    }

    /**
     *
     */
    public function down()
    {
        Schema::table("products", function ($table) {
            $table->dropColumn('is_available');
        });
    }
}