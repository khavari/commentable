<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateWidgetsTable extends Migration
{

  public function up()
  {
    Schema::create("widgets", function (Blueprint $table) {
        $table->string("code")->unique();
        $table->integer("order")->unsigned();
    });
  }

  public function down()
  {
    Schema::drop('widgets');
  }
}
