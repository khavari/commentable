<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

/**
 * Class AddDimensionsAndWeightToProducts
 */
class AddDimensionsAndWeightToProducts extends Migration
{

    /**
     *
     */
    public function up()
    {
        Schema::table('products', function (Blueprint $table) {
            $table->json('dimensions')->nullable()->default(null);
            $table->integer('weight')->nullable()->default(null);
        });
    }

    /**
     *
     */
    public function down()
    {
        Schema::table('products', function (Blueprint $table) {
            $table->dropColumn(['dimensions', 'weight']);
        });
    }

}
