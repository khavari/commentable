<?php

use Illuminate\Database\Migrations\Migration;

class CreateSeoInfoTable extends Migration
{
    public function up()
    {
        Schema::create('seo_info', function ($table) {
            $table->increments('id');
            $table->string('description');
            $table->string('keywords');
            $table->integer('content_id')->unsigned();
            $table->timestamps();
        });

        Schema::create('seo_info_translations', function ($table) {
            $table->increments('id');
            $table->integer('seo_info_id')->unsigned();
            $table->string('description');
            $table->string('keywords');
            $table->string('locale')->index();
            $table->timestamps();
        });

        Schema::table('seo_info_translations', function ($table) {
            $table->unique(['seo_info_id', 'locale']);
            $table->foreign('seo_info_id')->references('id')->on('seo_info')->onDelete('cascade');
        });
    }

    public function down()
    {
        Schema::drop('seo_info_translations');
        Schema::drop('seo_info');
    }
}
