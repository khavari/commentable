<?php


use Illuminate\Database\Migrations\Migration;

class AlterCategoriesTableAddOrderField extends Migration
{
    public function up()
    {
        Schema::table('product_categories', function ($table) {
            $table->integer('order')->nullable();
        });
    }

    public function down()
    {
        Schema::table("product_categories", function ($table) {
            $table->dropColumn('order');
        });
    }
}