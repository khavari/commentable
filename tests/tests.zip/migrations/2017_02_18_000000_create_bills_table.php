<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateBillsTable extends Migration
{
    public function up()
    {
        Schema::create("bills", function (Blueprint $table) {
            $table->bigIncrements("id");
            $table->integer('bill_information_id')->unsigned();
            $table->unsignedBigInteger('serial');
            $table->integer('invoice_id')->unsigned();
            $table->timestamp('issued_at');
            $table->boolean('canceled')->default(0);
            $table->timestamps();
        });

        Schema::table('bills', function (Blueprint $table) {
            $table->unique(['invoice_id']);
            $table->unique(['serial']);
        });
    }

    public function down()
    {
        Schema::dropIfExists('bills');
    }
}
