<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateInvoicesTable extends Migration
{
    public function up()
    {
        Schema::create('invoices', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->tinyInteger('status')->default(0)->index();
            $table->integer('user_id')->unsigned();
            $table->bigInteger('total')->index();
            $table->text('shipping_address')->nullable();
            $table->timestamps();
        });

        Schema::create('invoice_items', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->text('title');
            $table->bigInteger('fee');
            $table->integer('quantity')->index()->default(1);
            $table->bigInteger('total');
            $table->string('unit')->nullable();
            $table->bigInteger('discount')->index()->default(0);
            $table->bigInteger('invoice_id')->index()->unsigned();
            $table->text('description')->nullable()->default('');
            $table->timestamps();
        });

        Schema::create('invoice_logs', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->text('log');
            $table->smallInteger('code');
            $table->integer('user_id')->unsigned()->nullable()->default(null);
            $table->bigInteger('invoice_id')->unsigned();
            $table->string('ip')->nullable();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('invoice_logs');
        Schema::dropIfExists('invoice_items');
        Schema::dropIfExists('invoices');
    }
}
