<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateVisalineSkilledWorkersTable extends Migration
{
    public function up()
    {
        Schema::create("visaline_skilled_workers", function (Blueprint $table) {
            $table->increments('id');
            $table->string("fullname");
            $table->dateTime("date_of_birth");
            $table->string("email")->nullable();
            $table->string("phone");
            $table->string("country_code");
            $table->string("nationality");
            $table->string("country_of_residence");
            $table->integer('work_history')->unsigned()->default(0);
            $table->integer('work_history_in_canada')->unsigned()->default(0);
            $table->string("en_writing");
            $table->string("en_speaking");
            $table->string("en_listening");
            $table->string("en_reading");
            $table->string("fr_writing");
            $table->string("fr_speaking");
            $table->string("fr_listening");
            $table->string("fr_reading");
            $table->string("education");
            $table->enum("marital_status", [0 => "married", 1 => "unmarried", 2 => "divorced"]);
            $table->string("spouse_education")->nullable();
            $table->smallInteger("spouse_work_experience")->default(0);
            $table->boolean("spouse_language_test")->default(false);
            $table->smallInteger("children")->default(0);
            $table->boolean("relatives")->default(false);
            $table->text("additional_information")->nullable();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('visaline_skilled_workers');
    }
}
