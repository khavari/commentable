<?php


use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class AddEnterpriseFields extends Migration
{
    public function up()
    {
        Schema::table("contacts", function (Blueprint $table) {
            $table->string('first_name');
            $table->string('last_name');
            $table->string('company');
            $table->string('country');
            $table->string('city');
            $table->string("phone");
        });
    }

    public function down()
    {
        Schema::table('contacts', function (Blueprint $table) {
            $table->dropColumn(['first_name', 'last_name', 'company', 'country', 'city', 'phone']);
        });
    }
}
