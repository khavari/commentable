<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateEventCalendarOrdersTable extends Migration
{
    public function up()
    {
        Schema::create("event_calendar_orders", function (Blueprint $table) {
            $table->increments('id');
            $table->integer('event_id')->unsigned();
            $table->string('first_name');
            $table->string('last_name');
            $table->string('national_id');
            $table->string('birthday');
            $table->string('phone');
            $table->string('first_name_en')->nullable();
            $table->string('last_name_en')->nullable();
            $table->string('job')->nullable();
            $table->string('workplace')->nullable();
            $table->text('workplace_address')->nullable();
            $table->string('email');
            $table->string('education');
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfexists('event_calendar_orders');
    }
}
