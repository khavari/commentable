<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class UpdateEventCalendarOrderTable extends Migration
{
    public function up()
    {
        Schema::table("event_calendar_orders", function (Blueprint $table) {
            $table->string('photo1')->nullable();
            $table->string('photo2')->nullable();
            $table->string('workplace_phone')->nullable();
        });
    }

    public function down()
    {
        Schema::table("event_calendar_orders", function (Blueprint $table) {
            $table->dropColumn('photo1');
            $table->dropColumn('photo2');
            $table->dropColumn('workplace_phone');
        });
    }
}
