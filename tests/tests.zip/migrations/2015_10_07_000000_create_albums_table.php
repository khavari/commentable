<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateAlbumsTable extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::create('albums', function (Blueprint $table) {
            $table->increments('id');
            $table->string('title');
            $table->text("description");
            $table->softDeletes();
            $table->timestamps();
        });

        Schema::create('album_translations', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('album_id')->unsigned();
            $table->string("title")->nullable();
            $table->text("description");
            $table->string('locale')->index();
        });

        Schema::table("album_translations", function (Blueprint $table) {
            $table->unique(['album_id', 'locale']);
            $table->foreign('album_id')->references('id')->on('albums')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down()
    {
        Schema::drop('album_translations');

        Schema::drop('albums');
    }
}
