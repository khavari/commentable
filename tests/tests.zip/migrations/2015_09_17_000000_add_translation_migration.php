<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class AddTranslationMigration extends Migration
{
    public function up()
    {
        Schema::create("attribute_translations", function (Blueprint $table) {
            $table->increments('id');
            $table->integer('attribute_id')->unsigned();
            $table->string('title')->nullable();
            $table->string('default')->nullable();
            $table->string('locale')->index();
        });
        Schema::table("attribute_translations", function (Blueprint $table) {
            $table->unique(['attribute_id', 'locale']);
            $table->foreign('attribute_id')->references('id')->on('attributes')->onDelete('cascade');
        });


        Schema::create("attribute_set_translations", function (Blueprint $table) {
            $table->increments('id');
            $table->integer('attribute_set_id')->unsigned();
            $table->string('title')->nullable();
            $table->string('locale')->index();
        });

        Schema::table("attribute_set_translations", function (Blueprint $table) {
            $table->unique(['attribute_set_id', 'locale']);
            $table->foreign('attribute_set_id')->references('id')->on('attribute_sets')->onDelete('cascade');
        });


        Schema::create("product_category_translations", function (Blueprint $table) {
            $table->increments('id');
            $table->integer('category_id')->unsigned();
            $table->string('title');
            $table->string('description');
            $table->string('slug');
            $table->string('locale')->index();
        });
        Schema::table("product_category_translations", function (Blueprint $table) {
            $table->unique(['category_id', 'locale']);
            $table->foreign('category_id')->references('id')->on('product_categories')->onDelete('cascade');
        });


        Schema::create("product_translations", function (Blueprint $table) {
            $table->increments('id');
            $table->integer('product_id')->unsigned();
            $table->string('title');
            $table->mediumText('description');
            $table->bigInteger('price')->unsigned();
            $table->string('slug');
            $table->string('locale');
        });

        Schema::table("product_translations", function (Blueprint $table) {
            $table->unique(['product_id', 'locale']);
            $table->foreign('product_id')->references('id')->on('products')->onDelete('cascade');
        });

    }

    public function down()
    {
        Schema::drop(['attribute_translations', 'attribute_set_translations', 'product_category_translations', 'product_translations']);
    }
}
