<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class AlterUsersTableAddOptionsField extends Migration
{
    public function up()
    {
        Schema::table("users", function (Blueprint $table) {
            $table->json("options")->nullable();
        });
    }

    public function down()
    {
        Schema::table("users", function ($table) {
              $table->dropColumn(['options']);
        });
    }
}
