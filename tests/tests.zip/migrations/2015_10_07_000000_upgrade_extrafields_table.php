<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class UpgradeExtrafieldsTable extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::table('extrafields', function (Blueprint $table) {
            $table->dropColumn('type');

        });

        Schema::table("extrafields", function (Blueprint $table) {
            $table->json("type")->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down()
    {
        Schema::table("extrafields", function (Blueprint $table) {
            $table->dropColumn("type");
        });

        Schema::table("extrafields", function (Blueprint $table) {
            $table->enum('type', ['string', 'text']);
        });
    }
}
