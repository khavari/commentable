<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateEventCalendarTable extends Migration
{
    public function up()
    {
        //['title', 'began_at', 'ended_at', 'details', 'pr_phone', 'slug', 'city', 'state', 'website', 'phone','email', 'hours'];
        Schema::create("calendar_events", function (Blueprint $table) {
            $table->increments('id');
            $table->timestamp('began_at');
            $table->timestamp('ended_at')->nullable();
            $table->timestamps();
        });

        Schema::create("calendar_event_translations", function (Blueprint $table) {
            $table->increments('id');
            $table->integer('calendar_event_id')->unsigned();
            $table->string('title');

            $table->longText('details');
            $table->string('pr_phone');
            $table->string('slug');
            $table->string('city');
            $table->string('state');
            $table->string('website');
            $table->string('phone');
            $table->string('fax');
            $table->string('email');
            $table->boolean('hours');
            $table->timestamps();

            $table->string('locale')->index();
            $table->unique(['locale', 'calendar_event_id']);
            $table->foreign('calendar_event_id')->references('id')->on('calendar_events')->onDelete('cascade');
        });
    }

    public function down()
    {
        Schema::dropIfExists('calendar_event_translations');
        Schema::dropIfExists('calendar_events');
    }
}
