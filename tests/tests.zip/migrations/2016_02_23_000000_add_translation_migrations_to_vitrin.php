<?php

use Illuminate\Database\Migrations\Migration;

class AddTranslationMigrationsToVitrin extends Migration
{
    public function up()
    {
        Schema::create('slide_translations', function ($table) {
            $table->increments('id');
            $table->integer('slide_id')->unsigned();
            $table->text('description')->nullable();
            $table->text('link')->nullable();
            $table->string('locale')->index();
        });

        Schema::table('slide_translations', function ($table) {
            $table->unique(['slide_id', 'locale']);
            $table->foreign('slide_id')->references('id')->on('slides')->onDelete('cascade');
        });
    }

    public function down()
    {
        Schema::dropIfExists('slide_translations');
    }
}
