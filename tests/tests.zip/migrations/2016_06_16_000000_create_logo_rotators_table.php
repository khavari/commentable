<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateLogoRotatorsTable extends Migration
{

    public function down()
    {
        Schema::drop('logo-rotators');
    }

    public function up()
    {
        Schema::create("logo-rotators", function (Blueprint $table) {
            $table->increments('id');
            $table->string("url");
            $table->string("hyper_link")->default("#");
            $table->integer("order")->unsigned();
            $table->string("alt_text");
        });
    }
}
