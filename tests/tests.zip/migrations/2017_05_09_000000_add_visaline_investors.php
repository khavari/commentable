<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class AddVisalineInvestors extends Migration
{
    public function up()
    {
        Schema::create("visaline_business_evaluations", function (Blueprint $table) {
            $table->bigIncrements("id");
            $table->string("fullname");
            $table->dateTime("date_of_birth");
            $table->string("email")->nullable();
            $table->string("phone");
            $table->string("country_code");
            $table->string("nationality");
            $table->string("country_of_residence");
            $table->boolean("owned_business")->default(false);
            $table->boolean("managed_business")->default(false);
            $table->string("net_worth")->default(0);
            $table->string("en_writing");
            $table->string("en_speaking");
            $table->string("en_listening");
            $table->string("en_reading");
            $table->string("fr_writing");
            $table->string("fr_speaking");
            $table->string("fr_listening");
            $table->string("fr_reading");
            $table->string("education");
            $table->string("marital_status")->default(1);
            $table->string("spouse_education")->nullable();
            $table->smallInteger("spouse_work_experience")->default(0);
            $table->boolean("spouse_language_test")->default(false);
            $table->smallInteger("children_under_19")->default(0);
            $table->boolean("relatives")->default(false);
            $table->text("relatives_description")->nullable();
            $table->text("additional_information")->nullable();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists("visaline_business_evaluations");
    }
}
