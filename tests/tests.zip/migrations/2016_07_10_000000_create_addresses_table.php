<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateAddressesTable extends Migration
{
    public function up()
    {
        Schema::create('addresses', function (Blueprint $table) {
            $table->bigInteger('id');
            $table->string('country');
            $table->string('city');
            $table->string('province');
            $table->string('address');
            $table->string('number');
            $table->string('unit')->nullable();
            $table->integer('user_id')->unsigned();
            $table->string('zip');
        });
    }

    public function down()
    {
        Schema::drop('addresses');
    }
}
