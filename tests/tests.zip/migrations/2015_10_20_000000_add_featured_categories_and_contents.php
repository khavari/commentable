<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class AddFeaturedCategoriesAndContents extends Migration {

    public function up()
    {
        Schema::table("categories", function (Blueprint $table) {
            $table->boolean("featured")->default(false);
        });

        Schema::table("contents", function (Blueprint $table) {
            $table->boolean("featured")->default(false);
        });
    }

    public function down()
    {
        Schema::table("categories", function (Blueprint $table) {
            $table->dropColumn("featured");
        });

        Schema::table("contents", function (Blueprint $table) {
            $table->dropColumn("featured");
        });
    }
}
