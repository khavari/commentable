<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class InstallMenus extends Migration {

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::dropIfExists("links");
        Schema::dropIfExists("menus");
        Schema::create("links", function (Blueprint $table) {
            $table->increments("id");
            $table->string("title");
            $table->string("icon");
            $table->string("url");
            $table->integer("order");
            $table->integer("parent_id")->nullable()->unsigned();
        });

        Schema::create("link_translations", function (Blueprint $table) {
            $table->increments("id");
            $table->string("title");
            $table->string("url");
            $table->integer("link_id")->unsigned();

            $table->string('locale')->index();
            $table->unique(['link_id', 'locale']);
            $table->foreign('link_id')->references('id')->on('links')->onDelete('cascade');
        });


        Schema::create("menus", function (Blueprint $table) {
            $table->increments('id');
            $table->string("position");
        });

        Schema::create("link_menu", function (Blueprint $table) {
            $table->increments("id");
            $table->integer("link_id")->unsigned();
            $table->integer("menu_id")->unsigned();

            $table->unique(['link_id', 'menu_id']);

            $table->foreign("link_id")->references("id")->on("links")->onDelete("cascade");
            $table->foreign("menu_id")->references("id")->on("menus")->onDelete("cascade");
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {

        Schema::table("link_menu", function (Blueprint $table) {
            $table->dropForeign('link_menu_link_id_foreign');
            $table->dropForeign('link_menu_menu_id_foreign');
        });

        Schema::drop("link_menu");

        Schema::drop("link_translations");

        Schema::drop("links");

        Schema::drop("menus");
    }
}