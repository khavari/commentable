<?php

class AddStatusToOrders extends \Illuminate\Database\Migrations\Migration
{
    public function up()
    {
        Schema::table("orders", function ($table) {
            $table->boolean('done')->default(0);
        });
    }

    public function down()
    {
        Schema::table("orders", function ($table) {
            $table->dropColumn('done');
        });
    }
}
