<?php

class UpdateOrdersTable extends \Illuminate\Database\Migrations\Migration
{
    public function up()
    {
        Schema::table("orders", function ($table) {
            $table->dropColumn('json');
        });

        Schema::table("orders", function ($table) {
            $table->text('json')->nullable();
        });
    }

    public function down()
    {
        Schema::table("orders", function ($table) {
            $table->dropColumn('json');
        });

        Schema::table("orders", function ($table) {
            $table->string('json');
        });
    }
}
