<?php


use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class InstallContactPackage extends Migration
{
    public function up()
    {
        Schema::table("contacts", function (Blueprint $table) {
            $table->dropIfExists('contacts');
        });

        Schema::create("contacts", function (Blueprint $table) {
            $table->increments('id');
            $table->string('email');
            $table->mediumText("body");
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::drop("contacts");
    }
}
