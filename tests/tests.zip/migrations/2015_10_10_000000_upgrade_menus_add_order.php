<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class UpgradeMenusAddOrder extends Migration
{

    public function up()
    {
        Schema::table("links", function (Blueprint $table) {
            $table->dropColumn("order");
        });

        Schema::table("link_menu", function (Blueprint $table) {
            $table->integer("order");
        });
    }

    public function down()
    {
        Schema::table("links", function (Blueprint $table) {
            $table->integer("order");
        });
        Schema::table("link_menu", function (Blueprint $table) {
            $table->dropColumn("order");
        });
    }
}