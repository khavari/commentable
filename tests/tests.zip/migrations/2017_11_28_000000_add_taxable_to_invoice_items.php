<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class AddTaxableToInvoiceItems extends Migration
{
    public function up()
    {
        Schema::table("invoice_items", function (Blueprint $table) {
            $table->boolean('taxable')->default(true)->after('invoice_id');
        });
    }

    public function down()
    {
        Schema::table("invoice_items", function (Blueprint $table) {
            $table->dropColumn('taxable');
        });
    }
}
