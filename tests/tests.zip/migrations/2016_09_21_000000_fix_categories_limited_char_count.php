<?php

use Illuminate\Database\Migrations\Migration;

class FixCategoriesLimitedCharCount extends Migration
{
    public function up()
    {
        \DB::statement('ALTER TABLE category_translations MODIFY COLUMN description TEXT');
    }

    public function down()
    {
        \DB::statement('ALTER TABLE category_translations MODIFY COLUMN description VARCHAR(255)');
    }
}
