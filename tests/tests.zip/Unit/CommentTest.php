<?php

namespace Tests\Unit;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Easteregg\Comment\Comment;

class CommentTest extends TestCase
{

    /**
     * @test
     */
    public function it_visits_home_page()
    {
        $this->visit('/')->see('Woodward');
    }

    /**
     * @test
     */
    public function testBasicTestd()
    {
        $this->assertTrue(true);
    }



}
